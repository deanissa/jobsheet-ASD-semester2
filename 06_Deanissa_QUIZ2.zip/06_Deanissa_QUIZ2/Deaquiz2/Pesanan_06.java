package Deaquiz2;

public class Pesanan_06 {
    int kodePesanan;
    String namaPesanan;
    int harga;

    public Pesanan_06(int kodePesanan, String namaPesanan, int harga) {
        this.kodePesanan = kodePesanan;
        this.namaPesanan = namaPesanan;
        this.harga = harga;
}
}
